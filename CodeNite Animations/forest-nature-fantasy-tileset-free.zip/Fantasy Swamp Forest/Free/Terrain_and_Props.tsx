<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="Terrain_and_Props" tilewidth="16" tileheight="16" tilecount="680" columns="20">
 <image source="Terrain_and_Props.png" width="320" height="544"/>
</tileset>
