<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="BG_2" tilewidth="16" tileheight="16" tilecount="2825" columns="113">
 <image source="BG_2/BG_2.png" width="1817" height="400"/>
</tileset>
